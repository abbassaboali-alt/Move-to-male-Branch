import React, { useEffect, useState } from 'react';
import { verifyAuth, logoutAll, getStoredToken } from '../services/authService';

interface AuthGateProps {
  children: React.ReactNode;
}

export const AuthGate: React.FC<AuthGateProps> = ({ children }) => {
  const [authState, setAuthState] = useState<'pending' | 'authorized' | 'net_error'>('pending');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    let active = true;

    async function checkAuthentication() {
      // If standalone and definitely no token, redirect immediately without delay
      if (typeof window !== 'undefined' && window.parent === window && !getStoredToken()) {
        logoutAll();
        return;
      }

      try {
        const session = await verifyAuth();
        if (!active) return;

        if (session && session.profile?.roles?.includes('admin')) {
          setAuthState('authorized');
        } else {
          logoutAll();
        }
      } catch (err: any) {
        if (!active) return;
        console.error('Authentication verification error:', err);

        if (err?.message === 'AUTH_REQUIRED') {
          logoutAll();
        } else {
          setErrorMessage(err?.message || 'Connection to Prudle is temporarily unavailable.');
          setAuthState('net_error');
        }
      }
    }

    checkAuthentication();

    return () => {
      active = false;
    };
  }, []);

  if (authState === 'authorized') {
    return <>{children}</>;
  }

  if (authState === 'net_error') {
    return (
      <aside
        id="prudle-worker-connection-error"
        style={{
          position: 'fixed',
          zIndex: 2147483647,
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '16px',
          background: '#f5f7fb',
          color: '#164478',
          font: '700 16px Arial, sans-serif',
          textAlign: 'center',
          padding: '20px',
          visibility: 'visible'
        }}
      >
        <div className="text-lg font-bold">
          {errorMessage || 'Connection to Prudle is temporarily unavailable.'}
        </div>
        <button
          type="button"
          style={{
            background: '#164478',
            color: 'white',
            border: 0,
            borderRadius: '9px',
            padding: '12px 28px',
            font: '700 15px Arial, sans-serif',
            cursor: 'pointer'
          }}
          onClick={() => window.location.reload()}
        >
          Retry
        </button>
      </aside>
    );
  }

  // Pending verification state (safe invisible skeleton during pre-render gate)
  return null;
};

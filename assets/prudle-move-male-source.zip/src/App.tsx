import React, { useState, useEffect, useMemo, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { AuthGate } from './components/AuthGate';
import { Header } from './components/Header';
import { FiltersBar } from './components/FiltersBar';
import { StudentsTable } from './components/StudentsTable';
import { SingleFeeModal } from './components/modals/SingleFeeModal';
import { SingleLevelModal } from './components/modals/SingleLevelModal';
import { BulkFeeModal } from './components/modals/BulkFeeModal';
import { BulkLevelModal } from './components/modals/BulkLevelModal';
import { MigrateModal } from './components/modals/MigrateModal';
import {
  fetchStagingStudents,
  populateStudentLevels,
  subscribeToOpenCourses,
  migrateStudentRecord,
  undoStudentRecord,
  deleteStudentRecord,
  updateStudentField,
  updateStudentFees,
  updateStudentLevels,
  importExcelRows,
  safeNumber,
  cleanDigits
} from './services/workerService';
import { CourseRecord, FilterState, Language, StudentRecord, UndoRecord } from './types';
import { translations } from './i18n/translations';

const MainApp: React.FC = () => {
  // Language initialization (Section 37: English MUST be default on first visit)
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('prudle.ui.language');
      if (saved === 'ar' || saved === 'en') return saved;
    } catch {}
    return 'en';
  });

  const t = translations[lang];

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try {
      localStorage.setItem('prudle.ui.language', lang);
    } catch {}
  }, [lang]);

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'en' ? 'ar' : 'en'));
  };

  // State
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [hintText, setHintText] = useState<string>('');
  const [targetCourses, setTargetCourses] = useState<CourseRecord[]>([]);
  const [selectedTargetCourseId, setSelectedTargetCourseId] = useState<string>('');
  const [dupMode, setDupMode] = useState<boolean>(false);
  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());
  const [levelsOverride, setLevelsOverride] = useState<Record<string, number>>({});
  const [undoMap, setUndoMap] = useState<Record<string, UndoRecord>>({});

  // Filter state
  const [filters, setFilters] = useState<FilterState>({
    status: '',
    name: '',
    age: '',
    iqama: '',
    phone: '',
    course: '',
    period: '',
    room: '',
    date: ''
  });

  // Modals state
  const [feesModalStudent, setFeesModalStudent] = useState<StudentRecord | null>(null);
  const [levelsModalStudent, setLevelsModalStudent] = useState<StudentRecord | null>(null);
  const [isBulkFeesOpen, setIsBulkFeesOpen] = useState<boolean>(false);
  const [isBulkLevelsOpen, setIsBulkLevelsOpen] = useState<boolean>(false);
  const [migrateModalStudent, setMigrateModalStudent] = useState<StudentRecord | null>(null);

  const getStudentKey = useCallback((s: StudentRecord) => `${s.src}__${s.id}`, []);

  // Fetch student data with progressive level loading
  const loadData = useCallback(async () => {
    setLoading(true);
    setHintText('');
    setSelectedKeys(new Set());

    try {
      const stagingList = await fetchStagingStudents();
      setStudents(stagingList);
      setLoading(false);

      // Progressively resolve student levels without blocking table view
      populateStudentLevels(stagingList).then((populated) => {
        setStudents(populated);
      });
    } catch (err: any) {
      console.error('Error loading staging students:', err);
      setStudents([]);
      setHintText(
        err?.code === 'RESULT_LIMIT_REACHED'
          ? 'Worker query reached 500 records. Worker pagination required.'
          : 'Failed to retrieve migration records.'
      );
      setLoading(false);
    }
  }, []);

  // Subscribe to open courses for Al-Hamdaniya (Male Branch)
  useEffect(() => {
    const unsubscribe = subscribeToOpenCourses(
      (courses) => {
        setTargetCourses(courses);
      },
      (err) => {
        console.error('Failed to load open Al-Hamdaniya male branch courses:', err);
        setTargetCourses([]);
      }
    );

    loadData();

    return () => {
      unsubscribe();
    };
  }, [loadData]);

  // Derived available options for dropdowns
  const availableCourses = useMemo(() => {
    return [...new Set(students.map((s) => s.course).filter(Boolean))].sort();
  }, [students]);

  const availablePeriods = useMemo(() => {
    return [...new Set(students.map((s) => s.period).filter(Boolean))].sort();
  }, [students]);

  const availableRooms = useMemo(() => {
    return [...new Set(students.map((s) => s.room).filter(Boolean))].sort();
  }, [students]);

  const availableDates = useMemo(() => {
    return [...new Set(students.map((s) => s.date).filter(Boolean))].sort();
  }, [students]);

  // Duplicates map
  const dupMap = useMemo(() => {
    const map: Record<string, number> = {};
    for (const s of students) {
      const iq = cleanDigits(s.iqama);
      if (iq) map[`iq:${iq}`] = (map[`iq:${iq}`] || 0) + 1;

      const nm = String(s.name_en || '').trim().toLowerCase();
      if (nm) map[`nm:${nm}`] = (map[`nm:${nm}`] || 0) + 1;
    }
    return map;
  }, [students]);

  const isDuplicateStudent = useCallback(
    (s: StudentRecord) => {
      const iq = cleanDigits(s.iqama);
      const nm = String(s.name_en || '').trim().toLowerCase();
      const countIq = iq && dupMap[`iq:${iq}`] ? dupMap[`iq:${iq}`] : 0;
      const countNm = nm && dupMap[`nm:${nm}`] ? dupMap[`nm:${nm}`] : 0;
      return countIq > 1 || countNm > 1;
    },
    [dupMap]
  );

  // Filtered students list
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      // Status filter
      if (!filters.status) {
        if (s.status === 'pass' || s.status === 'fail') return false;
      } else {
        if (s.status !== filters.status) return false;
      }

      // Name filter
      if (filters.name) {
        const query = filters.name.toLowerCase();
        const combined = `${s.name_en || ''} ${s.name || ''} ${s.name_ar || ''}`.toLowerCase();
        if (!combined.includes(query)) return false;
      }

      // Age filter
      if (filters.age && s.age !== cleanDigits(filters.age)) return false;

      // Iqama filter
      if (filters.iqama && !String(s.iqama || '').includes(cleanDigits(filters.iqama))) return false;

      // Phone filter
      if (filters.phone && !String(s.phone || '').includes(cleanDigits(filters.phone))) return false;

      // Course filter
      if (filters.course && s.course !== filters.course) return false;

      // Period filter
      if (filters.period && s.period !== filters.period) return false;

      // Room filter
      if (filters.room && s.room !== filters.room) return false;

      // Date filter
      if (filters.date && s.date !== filters.date) return false;

      // Duplicates mode
      if (dupMode && !isDuplicateStudent(s)) return false;

      return true;
    });
  }, [students, filters, dupMode, isDuplicateStudent]);

  // Update hint text when filtered list changes
  useEffect(() => {
    if (loading) return;
    if (filteredStudents.length > 0) {
      setHintText(`${t.resultsCount}${filteredStudents.length}${dupMode ? t.onlyDuplicates : ''}`);
    } else {
      setHintText(t.noResults);
    }
  }, [filteredStudents.length, dupMode, loading, t]);

  // Selected target course record & display string
  const selectedTargetCourse = useMemo(() => {
    return targetCourses.find((c) => c.id === selectedTargetCourseId) || null;
  }, [targetCourses, selectedTargetCourseId]);

  const targetCourseText = useMemo(() => {
    if (!selectedTargetCourse) return '—';
    const period = String(selectedTargetCourse.Period || selectedTargetCourse.period || '').trim();
    return `${selectedTargetCourse.TrainingCourse || '—'} — ${period || '—'} — ${selectedTargetCourse.Trainer || '—'} — ${selectedTargetCourse.Room || selectedTargetCourse.room || '—'}`;
  }, [selectedTargetCourse]);

  // Filter change handler
  const handleFilterChange = (field: keyof FilterState, value: string) => {
    setFilters((prev) => ({ ...prev, [field]: value }));
  };

  // Selection handlers
  const handleToggleSelect = (student: StudentRecord) => {
    const key = getStudentKey(student);
    if (undoMap[key]) return; // Cannot select finished rows

    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const handleSelectAll = () => {
    const next = new Set<string>();
    filteredStudents.forEach((s) => {
      const key = getStudentKey(s);
      if (!undoMap[key]) next.add(key);
    });
    setSelectedKeys(next);
  };

  const handleSelectNone = () => {
    setSelectedKeys(new Set());
  };

  // Inline edit save
  const handleInlineSave = async (student: StudentRecord, field: string, value: string) => {
    await updateStudentField(student, field, value);

    // Instant UI sync
    setStudents((prev) =>
      prev.map((s) =>
        s.src === student.src && s.id === student.id ? { ...s, [field]: value.trim() } : s
      )
    );
  };

  // Single Fee save
  const handleSaveFees = async (
    student: StudentRecord,
    courseFee: number,
    paidAmount: number,
    remainingAmount: number,
    paymentType: string
  ) => {
    await updateStudentFees(student, courseFee, paidAmount, remainingAmount, paymentType);

    // Instant UI sync
    setStudents((prev) =>
      prev.map((s) =>
        s.src === student.src && s.id === student.id
          ? {
              ...s,
              CourseFee: courseFee,
              PaidAmount: paidAmount,
              RemainingAmount: remainingAmount,
              PaymentType: paymentType
            }
          : s
      )
    );
  };

  // Single Level save (Override before migration)
  const handleSaveLevels = async (
    student: StudentRecord,
    totalLevels: number,
    usedLevels: number,
    remainingLevels: number
  ) => {
    const key = getStudentKey(student);
    setLevelsOverride((prev) => ({ ...prev, [key]: totalLevels }));

    await updateStudentLevels(student, totalLevels, usedLevels, remainingLevels);

    // Instant UI sync
    setStudents((prev) =>
      prev.map((s) =>
        s.src === student.src && s.id === student.id
          ? {
              ...s,
              totalLevels,
              usedLevels,
              remainingLevels
            }
          : s
      )
    );
  };

  // Bulk Fees Apply
  const handleApplyBulkFees = async (feeVal: number | null, paidVal: number | null) => {
    const selected = students.filter((s) => selectedKeys.has(getStudentKey(s)));
    if (!selected.length) return;

    for (const s of selected) {
      const originalFee = safeNumber(s.CourseFee, 0);
      const originalPaid = safeNumber(s.PaidAmount, 0);
      const newFee = feeVal === null ? originalFee : feeVal;
      const newPaid = paidVal === null ? originalPaid : paidVal;
      const newRem = Math.max(newFee - newPaid, 0);

      await updateStudentFees(s, newFee, newPaid, newRem, s.PaymentType || '');
    }

    // Instant UI sync
    setStudents((prev) =>
      prev.map((s) => {
        if (selectedKeys.has(getStudentKey(s))) {
          const originalFee = safeNumber(s.CourseFee, 0);
          const originalPaid = safeNumber(s.PaidAmount, 0);
          const newFee = feeVal === null ? originalFee : feeVal;
          const newPaid = paidVal === null ? originalPaid : paidVal;
          const newRem = Math.max(newFee - newPaid, 0);
          return {
            ...s,
            CourseFee: newFee,
            PaidAmount: newPaid,
            RemainingAmount: newRem
          };
        }
        return s;
      })
    );

    setSelectedKeys(new Set());
  };

  // Bulk Levels Apply
  const handleApplyBulkLevels = (totalLevelsVal: number) => {
    const selected = students.filter((s) => selectedKeys.has(getStudentKey(s)));
    if (!selected.length) return;

    setLevelsOverride((prev) => {
      const next = { ...prev };
      selected.forEach((s) => {
        next[getStudentKey(s)] = totalLevelsVal;
      });
      return next;
    });

    setSelectedKeys(new Set());
  };

  // Migrate action
  const executeMigration = async (
    student: StudentRecord,
    totalLevels: number,
    courseFee: number,
    paidAmount: number,
    remainingAmount: number
  ) => {
    if (!selectedTargetCourse) {
      alert(t.alertTargetUnavailable);
      return;
    }

    const key = getStudentKey(student);
    if (undoMap[key]) return;

    const { undoRecord } = await migrateStudentRecord(
      student,
      selectedTargetCourse,
      totalLevels,
      courseFee,
      paidAmount,
      remainingAmount
    );

    setUndoMap((prev) => ({
      ...prev,
      [key]: undoRecord
    }));
  };

  const handleMigrateTrigger = async () => {
    const selected = students.filter((s) => selectedKeys.has(getStudentKey(s)));
    if (!selected.length) {
      alert(t.alertSelectOne);
      return;
    }

    if (!selectedTargetCourseId || !selectedTargetCourse) {
      alert(t.alertSelectTargetCourse);
      return;
    }

    // If single student, open the Migration Modal for final confirmation
    if (selected.length === 1) {
      setMigrateModalStudent(selected[0]);
    } else {
      // Bulk migration loop
      for (const s of selected) {
        const key = getStudentKey(s);
        const total = levelsOverride[key] || safeNumber(s.totalLevels, 0) || 12;
        const fee = safeNumber(s.CourseFee, 0) || safeNumber(selectedTargetCourse.CourseFee, 0);
        const paid = safeNumber(s.PaidAmount, 0);
        const rem = Math.max(fee - paid, 0);
        await executeMigration(s, total, fee, paid, rem);
      }
      setSelectedKeys(new Set());
    }
  };

  // Delete records action
  const handleDeleteSelected = async () => {
    const selected = students.filter((s) => selectedKeys.has(getStudentKey(s)));
    if (!selected.length) {
      alert(t.alertSelectRecords);
      return;
    }

    const newUndoState: Record<string, UndoRecord> = { ...undoMap };
    for (const s of selected) {
      const key = getStudentKey(s);
      const undoRec = await deleteStudentRecord(s);
      newUndoState[key] = undoRec;
    }

    setUndoMap(newUndoState);
    setSelectedKeys(new Set());
  };

  // Undo action
  const handleUndo = async (key: string) => {
    const undoItem = undoMap[key];
    if (!undoItem) {
      alert(t.alertNoUndo);
      return;
    }

    await undoStudentRecord(undoItem);

    setUndoMap((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  // Excel Export
  const handleExportExcel = () => {
    if (!filteredStudents.length) {
      alert(t.alertNoDataExport);
      return;
    }

    const exportRows = filteredStudents.map((s, idx) => {
      const key = getStudentKey(s);
      return {
        '#': idx + 1,
        'Name EN': (s.name_en || s.name || '').trim() || '—',
        'Name AR': s.name_ar || '',
        'Age': s.age || '',
        'National ID': s.iqama || '',
        'Phone': s.phone || '',
        'Previous Course': s.course || '',
        'Period': s.period || '',
        'Room': s.room || '',
        'Target Course': targetCourseText,
        'TotalLevels (students)': s.totalLevels,
        'UsedLevels (students)': s.usedLevels,
        'RemainingLevels (students)': s.remainingLevels,
        'TotalLevels Override': levelsOverride[key] || '',
        'CourseFee': safeNumber(s.CourseFee, 0),
        'PaidAmount': safeNumber(s.PaidAmount, 0),
        'RemainingAmount': safeNumber(s.RemainingAmount, 0),
        'Grade': s.grade === 0 || s.grade ? s.grade : '',
        'Status': s.status === 'pass' ? 'Passed' : s.status === 'fail' ? 'Failed' : 'New',
        'Date': s.date || ''
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Promotion_Report');
    XLSX.writeFile(workbook, 'Promotion_Report.xlsx');
  };

  // Excel Import
  const handleImportExcel = async (file: File) => {
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows: any[] = XLSX.utils.sheet_to_json(firstSheet);

      const importedCount = await importExcelRows(rows);
      alert(`${t.alertImportSuccess}${importedCount}${t.alertImportRecords}`);
      loadData();
    } catch (err) {
      console.error(err);
      alert(t.alertImportError);
    }
  };

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="prudle-app">
      {/* Header Banner & Language Toggle */}
      <Header lang={lang} onToggleLang={toggleLanguage} />

      {/* Filters and Action Bar */}
      <FiltersBar
        filters={filters}
        onFilterChange={handleFilterChange}
        availableCourses={availableCourses}
        availablePeriods={availablePeriods}
        availableRooms={availableRooms}
        availableDates={availableDates}
        targetCourses={targetCourses}
        selectedTargetCourseId={selectedTargetCourseId}
        onTargetCourseChange={setSelectedTargetCourseId}
        dupMode={dupMode}
        onToggleDupMode={() => setDupMode((prev) => !prev)}
        onSelectAll={handleSelectAll}
        onSelectNone={handleSelectNone}
        onMigrate={handleMigrateTrigger}
        onDelete={handleDeleteSelected}
        onOpenBulkFees={() => {
          if (!selectedKeys.size) return alert(t.alertSelectRecords);
          setIsBulkFeesOpen(true);
        }}
        onOpenBulkLevels={() => {
          if (!selectedKeys.size) return alert(t.alertSelectRecords);
          setIsBulkLevelsOpen(true);
        }}
        onExportExcel={handleExportExcel}
        onImportExcel={handleImportExcel}
        hintText={hintText}
        disabledButtons={loading}
        lang={lang}
      />

      {/* Main Students Table */}
      <StudentsTable
        students={filteredStudents}
        selectedKeys={selectedKeys}
        onToggleSelect={handleToggleSelect}
        targetText={targetCourseText}
        levelsOverride={levelsOverride}
        undoMap={undoMap}
        dupMap={dupMap}
        onInlineSave={handleInlineSave}
        onOpenFees={setFeesModalStudent}
        onOpenLevels={setLevelsModalStudent}
        onUndo={handleUndo}
        loading={loading}
        lang={lang}
      />

      {/* Modals */}
      <SingleFeeModal
        student={feesModalStudent}
        isOpen={Boolean(feesModalStudent)}
        onClose={() => setFeesModalStudent(null)}
        onSave={handleSaveFees}
        lang={lang}
      />

      <SingleLevelModal
        student={levelsModalStudent}
        isOpen={Boolean(levelsModalStudent)}
        onClose={() => setLevelsModalStudent(null)}
        onSave={handleSaveLevels}
        lang={lang}
      />

      <BulkFeeModal
        isOpen={isBulkFeesOpen}
        selectedCount={selectedKeys.size}
        onClose={() => setIsBulkFeesOpen(false)}
        onApply={handleApplyBulkFees}
        lang={lang}
      />

      <BulkLevelModal
        isOpen={isBulkLevelsOpen}
        selectedCount={selectedKeys.size}
        onClose={() => setIsBulkLevelsOpen(false)}
        onApply={handleApplyBulkLevels}
        lang={lang}
      />

      <MigrateModal
        student={migrateModalStudent}
        targetCourse={selectedTargetCourse}
        currentOverride={migrateModalStudent ? levelsOverride[getStudentKey(migrateModalStudent)] : undefined}
        isOpen={Boolean(migrateModalStudent)}
        onClose={() => setMigrateModalStudent(null)}
        onConfirm={async (student, levels, fee, paid, rem) => {
          const key = getStudentKey(student);
          setLevelsOverride((prev) => ({ ...prev, [key]: levels }));
          await executeMigration(student, levels, fee, paid, rem);
          setSelectedKeys(new Set());
        }}
        lang={lang}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthGate>
      <MainApp />
    </AuthGate>
  );
}

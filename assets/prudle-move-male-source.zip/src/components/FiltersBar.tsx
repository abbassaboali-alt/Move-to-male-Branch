import React, { useRef } from 'react';
import { CourseRecord, FilterState, Language } from '../types';
import { translations } from '../i18n/translations';

interface FiltersBarProps {
  filters: FilterState;
  onFilterChange: (field: keyof FilterState, value: string) => void;
  availableCourses: string[];
  availablePeriods: string[];
  availableRooms: string[];
  availableDates: string[];
  targetCourses: CourseRecord[];
  selectedTargetCourseId: string;
  onTargetCourseChange: (id: string) => void;
  dupMode: boolean;
  onToggleDupMode: () => void;
  onSelectAll: () => void;
  onSelectNone: () => void;
  onMigrate: () => void;
  onDelete: () => void;
  onOpenBulkFees: () => void;
  onOpenBulkLevels: () => void;
  onExportExcel: () => void;
  onImportExcel: (file: File) => void;
  hintText: string;
  disabledButtons: boolean;
  lang: Language;
}

export const FiltersBar: React.FC<FiltersBarProps> = ({
  filters,
  onFilterChange,
  availableCourses,
  availablePeriods,
  availableRooms,
  availableDates,
  targetCourses,
  selectedTargetCourseId,
  onTargetCourseChange,
  dupMode,
  onToggleDupMode,
  onSelectAll,
  onSelectNone,
  onMigrate,
  onDelete,
  onOpenBulkFees,
  onOpenBulkLevels,
  onExportExcel,
  onImportExcel,
  hintText,
  disabledButtons,
  lang
}) => {
  const t = translations[lang];
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportClick = () => {
    const file = fileInputRef.current?.files?.[0];
    if (file) {
      onImportExcel(file);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } else {
      alert(t.alertSelectExcel);
    }
  };

  return (
    <div className="filters">
      {/* Status Filter */}
      <select
        id="fStatus"
        value={filters.status}
        onChange={(e) => onFilterChange('status', e.target.value)}
      >
        <option value="">{t.statusAll}</option>
        <option value="new">{t.statusNew}</option>
        <option value="pass">{t.statusPass}</option>
        <option value="fail">{t.statusFail}</option>
      </select>

      {/* Inputs */}
      <input
        id="fName"
        type="text"
        placeholder={t.namePlaceholder}
        value={filters.name}
        onChange={(e) => onFilterChange('name', e.target.value)}
      />

      <input
        id="fAge"
        type="text"
        placeholder={t.agePlaceholder}
        value={filters.age}
        onChange={(e) => onFilterChange('age', e.target.value)}
      />

      <input
        id="fIqama"
        type="text"
        placeholder={t.iqamaPlaceholder}
        value={filters.iqama}
        onChange={(e) => onFilterChange('iqama', e.target.value)}
      />

      <input
        id="fPhone"
        type="text"
        placeholder={t.phonePlaceholder}
        value={filters.phone}
        onChange={(e) => onFilterChange('phone', e.target.value)}
      />

      {/* Course Select */}
      <select
        id="fCourse"
        value={filters.course}
        onChange={(e) => onFilterChange('course', e.target.value)}
      >
        <option value="">{t.courseSelect}</option>
        {availableCourses.map((c) => (
          <option key={c} value={c}>{c}</option>
        ))}
      </select>

      {/* Period Select */}
      <select
        id="fPeriod"
        value={filters.period}
        onChange={(e) => onFilterChange('period', e.target.value)}
      >
        <option value="">{t.periodSelect}</option>
        {availablePeriods.map((p) => (
          <option key={p} value={p}>{p}</option>
        ))}
      </select>

      {/* Room Select */}
      <select
        id="fRoom"
        value={filters.room}
        onChange={(e) => onFilterChange('room', e.target.value)}
      >
        <option value="">{t.roomSelect}</option>
        {availableRooms.map((r) => (
          <option key={r} value={r}>{r}</option>
        ))}
      </select>

      {/* Date Select */}
      <select
        id="fDate"
        value={filters.date}
        onChange={(e) => onFilterChange('date', e.target.value)}
      >
        <option value="">{t.dateSelect}</option>
        {availableDates.map((d) => (
          <option key={d} value={d}>{d}</option>
        ))}
      </select>

      {/* Target Course Select */}
      <select
        id="targetCourse"
        value={selectedTargetCourseId}
        onChange={(e) => onTargetCourseChange(e.target.value)}
        className="font-bold border-2 border-[#164478] bg-[#f8fbff]"
      >
        <option value="">{t.targetCourseSelect}</option>
        {targetCourses.map((tc) => {
          const per = String(tc.Period || tc.period || '').trim();
          const label = `${tc.TrainingCourse || '—'} — ${per || '—'} — ${tc.Trainer || '—'} — ${tc.Room || tc.room || '—'}`;
          return (
            <option key={tc.id} value={tc.id}>
              {label}
            </option>
          );
        })}
      </select>

      {/* Excel File Input */}
      <input
        ref={fileInputRef}
        id="excelFile"
        type="file"
        accept=".xlsx,.xls"
        className="hidden"
      />

      <button
        type="button"
        className="btn-blue"
        id="btnImportTrigger"
        disabled={disabledButtons}
        onClick={() => fileInputRef.current?.click()}
      >
        <i className="fa-solid fa-file-arrow-up mr-1 ml-1"></i>
        {t.btnImport}
      </button>

      {/* Hidden button for backward-compatible DOM id if checked */}
      <button
        type="button"
        id="btnImport"
        className="hidden"
        onClick={handleImportClick}
      >
        {t.btnImport}
      </button>

      {/* Export Report */}
      <button
        type="button"
        className="btn-green"
        id="btnExport"
        disabled={disabledButtons}
        onClick={onExportExcel}
      >
        <i className="fa-solid fa-file-excel mr-1 ml-1"></i>
        {t.btnExport}
      </button>

      {/* Migrate Button */}
      <button
        type="button"
        className="btn-green"
        id="btnMove"
        disabled={disabledButtons}
        onClick={onMigrate}
      >
        <i className="fa-solid fa-arrow-up-right-from-square mr-1 ml-1"></i>
        {t.btnMigrate}
      </button>

      {/* Bulk Fees */}
      <button
        type="button"
        className="btn-blue"
        id="btnBulkFees"
        disabled={disabledButtons}
        onClick={onOpenBulkFees}
      >
        <i className="fa-solid fa-hand-holding-dollar mr-1 ml-1"></i>
        {t.btnBulkFees}
      </button>

      {/* Bulk Levels */}
      <button
        type="button"
        className="btn-orange"
        id="btnBulkLevels"
        disabled={disabledButtons}
        onClick={onOpenBulkLevels}
      >
        <i className="fa-solid fa-layer-group mr-1 ml-1"></i>
        {t.btnBulkLevels}
      </button>

      {/* Select All */}
      <button
        type="button"
        className="btn-gray"
        id="btnSelectAll"
        disabled={disabledButtons}
        onClick={onSelectAll}
      >
        {t.btnSelectAll}
      </button>

      {/* Deselect All */}
      <button
        type="button"
        className="btn-gray"
        id="btnSelectNone"
        disabled={disabledButtons}
        onClick={onSelectNone}
      >
        {t.btnSelectNone}
      </button>

      {/* Delete Records */}
      <button
        type="button"
        className="btn-red"
        id="btnDel"
        disabled={disabledButtons}
        onClick={onDelete}
      >
        <i className="fa-solid fa-trash mr-1 ml-1"></i>
        {t.btnDelete}
      </button>

      {/* Duplicates Filter */}
      <button
        type="button"
        className={dupMode ? 'btn-red' : 'btn-gray'}
        id="btnDup"
        disabled={disabledButtons}
        onClick={onToggleDupMode}
      >
        <i className="fa-solid fa-clone mr-1 ml-1"></i>
        {dupMode ? t.btnDupModeActive : t.btnDupMode}
      </button>

      {/* Results hint */}
      <span id="hint">{hintText}</span>
    </div>
  );
};

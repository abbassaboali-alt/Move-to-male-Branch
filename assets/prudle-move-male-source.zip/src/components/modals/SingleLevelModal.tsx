import React, { useState, useEffect } from 'react';
import { Language, StudentRecord } from '../../types';
import { translations } from '../../i18n/translations';

interface SingleLevelModalProps {
  student: StudentRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (
    student: StudentRecord,
    totalLevels: number,
    usedLevels: number,
    remainingLevels: number
  ) => Promise<void>;
  lang: Language;
}

export const SingleLevelModal: React.FC<SingleLevelModalProps> = ({
  student,
  isOpen,
  onClose,
  onSave,
  lang
}) => {
  const t = translations[lang];
  const [totalLevels, setTotalLevels] = useState<number>(1);
  const [usedLevels, setUsedLevels] = useState<number>(0);
  const [saving, setSaving] = useState<boolean>(false);

  useEffect(() => {
    if (student) {
      const lastLevels = student._lastLevels || { total: 0, used: 0, remaining: 0 };
      const rawTotal = student.totalLevels === '—' ? lastLevels.total : Number(student.totalLevels);
      const rawUsed = student.usedLevels === '—' ? lastLevels.used : Number(student.usedLevels);
      setTotalLevels(rawTotal || 1);
      setUsedLevels(rawUsed || 0);
    }
  }, [student]);

  if (!isOpen || !student) return null;

  const remainingLevels = Math.max(totalLevels - usedLevels, 0);

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(student, totalLevels, usedLevels, remainingLevels);
      onClose();
    } catch (err) {
      console.error(err);
      alert(t.alertLevelsError);
    } finally {
      setSaving(false);
    }
  };

  const studentName = student.name_en || student.name || '—';

  return (
    <div className="modal" style={{ display: 'flex' }}>
      <div className="modal-box">
        <h3>{t.modalLevelsTitle}</h3>
        <div className="sub">{studentName} — {student.iqama || '—'}</div>

        <label>{t.lblTotalLevels}</label>
        <input
          type="number"
          min="1"
          value={totalLevels}
          onChange={(e) => setTotalLevels(Math.max(1, Math.floor(Number(e.target.value) || 0)))}
        />

        <label>{t.lblUsedLevels}</label>
        <input
          type="number"
          min="0"
          value={usedLevels}
          onChange={(e) => setUsedLevels(Math.max(0, Math.floor(Number(e.target.value) || 0)))}
        />

        <label>{t.lblRemainingLevels}</label>
        <input
          type="number"
          min="0"
          value={remainingLevels}
          disabled
        />

        <div className="modal-actions">
          <button
            className="btn-blue"
            type="button"
            disabled={saving}
            onClick={handleSave}
          >
            {saving ? t.btnSaving : t.btnSaveOverride}
          </button>
          <button
            className="btn-gray"
            type="button"
            disabled={saving}
            onClick={onClose}
          >
            {t.btnClose}
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';

interface BulkLevelModalProps {
  isOpen: boolean;
  selectedCount: number;
  onClose: () => void;
  onApply: (totalLevels: number) => void;
  lang: Language;
}

export const BulkLevelModal: React.FC<BulkLevelModalProps> = ({
  isOpen,
  selectedCount,
  onClose,
  onApply,
  lang
}) => {
  const t = translations[lang];
  const [totalLevelsInput, setTotalLevelsInput] = useState<string>('');

  if (!isOpen) return null;

  const handleApply = () => {
    const val = Math.floor(Number(totalLevelsInput) || 0);
    if (!val || val < 1) {
      alert(t.alertEnterValidNumber);
      return;
    }
    onApply(val);
    setTotalLevelsInput('');
    onClose();
  };

  return (
    <div className="modal" style={{ display: 'flex' }}>
      <div className="modal-box">
        <h3>{t.modalBulkLevelsTitle}</h3>
        <div className="sub">
          {t.modalBulkLevelsSub}
          {selectedCount}
          {t.modalBulkLevelsNote}
        </div>

        <label>{t.lblBulkTotalLevels}</label>
        <input
          type="number"
          min="1"
          placeholder="e.g. 12"
          value={totalLevelsInput}
          onChange={(e) => setTotalLevelsInput(e.target.value)}
        />

        <div className="modal-actions">
          <button
            className="btn-gray"
            type="button"
            onClick={onClose}
          >
            {t.btnCancel}
          </button>
          <button
            className="btn-blue"
            type="button"
            onClick={handleApply}
          >
            {t.btnApplySelected}
          </button>
        </div>
      </div>
    </div>
  );
};

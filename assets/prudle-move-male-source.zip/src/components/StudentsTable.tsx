import React, { useState } from 'react';
import { Language, StudentRecord, UndoRecord } from '../types';
import { translations } from '../i18n/translations';

interface StudentsTableProps {
  students: StudentRecord[];
  selectedKeys: Set<string>;
  onToggleSelect: (student: StudentRecord) => void;
  targetText: string;
  levelsOverride: Record<string, number>;
  undoMap: Record<string, UndoRecord>;
  dupMap: Record<string, number>;
  onInlineSave: (student: StudentRecord, field: string, value: string) => Promise<void>;
  onOpenFees: (student: StudentRecord) => void;
  onOpenLevels: (student: StudentRecord) => void;
  onUndo: (key: string) => Promise<void>;
  loading: boolean;
  lang: Language;
}

interface InlineEditingState {
  key: string;
  field: string;
  value: string;
}

export const StudentsTable: React.FC<StudentsTableProps> = ({
  students,
  selectedKeys,
  onToggleSelect,
  targetText,
  levelsOverride,
  undoMap,
  dupMap,
  onInlineSave,
  onOpenFees,
  onOpenLevels,
  onUndo,
  loading,
  lang
}) => {
  const t = translations[lang];
  const [editing, setEditing] = useState<InlineEditingState | null>(null);

  const getStudentKey = (s: StudentRecord) => `${s.src}__${s.id}`;

  const isDuplicate = (s: StudentRecord) => {
    const iq = String(s.iqama || '').replace(/\D/g, '');
    const nm = String(s.name_en || '').trim().toLowerCase();
    const countIq = iq && dupMap[`iq:${iq}`] ? dupMap[`iq:${iq}`] : 0;
    const countNm = nm && dupMap[`nm:${nm}`] ? dupMap[`nm:${nm}`] : 0;
    return countIq > 1 || countNm > 1;
  };

  const startEditing = (key: string, field: string, value: string) => {
    setEditing({ key, field, value });
  };

  const cancelEditing = () => {
    setEditing(null);
  };

  const handleInlineSave = async (student: StudentRecord) => {
    if (!editing) return;
    const { field, value } = editing;
    setEditing(null);
    await onInlineSave(student, field, value);
  };

  const renderRemainingAmount = (amount: number) => {
    const val = Math.max(0, Number(amount) || 0);
    return val > 0 ? (
      <span className="rem-red">{val}</span>
    ) : (
      <span className="rem-green">0</span>
    );
  };

  const renderStatus = (status: string) => {
    if (status === 'pass') return <span className="ok">{t.statusPass}</span>;
    if (status === 'fail') return <span className="bad">{t.statusFail}</span>;
    return <span className="new">{t.statusNew}</span>;
  };

  const isSubEnded = (total: any, used: any) => {
    const numTotal = Number(total) || 0;
    const numUsed = Number(used) || 0;
    return numTotal > 0 && numUsed >= numTotal;
  };

  return (
    <div className="table-wrap">
      <table id="mainTable" className="hide-private-cols">
        <thead>
          <tr>
            <th style={{ width: '44px' }}></th>
            <th style={{ width: '55px' }}>{t.thNum}</th>
            <th style={{ width: '270px' }}>{t.thName}</th>
            <th style={{ width: '90px' }}>{t.thAge}</th>
            <th style={{ width: '160px' }}>{t.thIqama}</th>
            <th style={{ width: '160px' }}>{t.thPhone}</th>
            <th style={{ width: '220px' }}>{t.thPrevCourse}</th>
            <th className="col-course">{t.thCurrentCourse}</th>
            <th className="col-period">{t.thPeriod}</th>
            <th className="col-trainer">{t.thTrainer}</th>
            <th className="col-room">{t.thRoom}</th>
            <th style={{ width: '320px' }}>{t.thTargetCourse}</th>
            <th style={{ width: '90px' }}>{t.thTotalLevels}</th>
            <th style={{ width: '90px' }}>{t.thUsedLevels}</th>
            <th style={{ width: '90px' }}>{t.thRemainingLevels}</th>
            <th style={{ width: '90px' }}>{t.thCourseFee}</th>
            <th style={{ width: '90px' }}>{t.thPaidAmount}</th>
            <th style={{ width: '90px' }}>{t.thRemainingAmount}</th>
            <th style={{ width: '120px' }}>{t.thPaymentType}</th>
            <th style={{ width: '80px' }}>{t.thGrade}</th>
            <th style={{ width: '90px' }}>{t.thStatus}</th>
            <th style={{ width: '120px' }}>{t.thDate}</th>
            <th style={{ width: '250px' }}>{t.thActions}</th>
            <th style={{ width: '250px' }}>{t.thResult}</th>
          </tr>
        </thead>
        <tbody id="tbody">
          {loading ? (
            <tr>
              <td colSpan={24} className="notice">
                <i className="fa-solid fa-spinner fa-spin mr-2 ml-2"></i>
                {t.loading}
              </td>
            </tr>
          ) : students.length === 0 ? (
            <tr>
              <td colSpan={24} className="notice">{t.noResults}</td>
            </tr>
          ) : (
            students.map((student, idx) => {
              const key = getStudentKey(student);
              const isDone = Boolean(undoMap[key]);
              const isDup = isDuplicate(student);
              const isSelected = selectedKeys.has(key);
              const domRowId = `${student.src}-${student.id}`;

              const overrideTotal = levelsOverride[key];
              const displayTotal = overrideTotal !== undefined ? overrideTotal : student.totalLevels;
              const displayUsed = student.usedLevels === 0 || student.usedLevels ? student.usedLevels : '—';
              const displayRem = student.remainingLevels === 0 || student.remainingLevels ? student.remainingLevels : '—';
              const undoItem = undoMap[key];

              const isFieldEditing = (f: string) => editing?.key === key && editing?.field === f;

              return (
                <tr
                  key={key}
                  id={`row-${domRowId}`}
                  className={`${isDone ? 'row-done' : ''} ${isDup ? 'dup-row' : ''}`}
                >
                  {/* Select Checkbox */}
                  <td>
                    <input
                      type="checkbox"
                      checked={isSelected}
                      disabled={isDone}
                      onChange={() => onToggleSelect(student)}
                    />
                  </td>

                  {/* Number */}
                  <td>{idx + 1}</td>

                  {/* Name (EN + AR + Duplicate Tag) */}
                  <td className="name-cell">
                    <div className={`inline ${isFieldEditing('name_en') ? 'editing' : ''}`}>
                      {isFieldEditing('name_en') ? (
                        <>
                          <input
                            autoFocus
                            value={editing?.value || ''}
                            onChange={(e) => setEditing((prev) => prev ? { ...prev, value: e.target.value } : null)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleInlineSave(student);
                              if (e.key === 'Escape') cancelEditing();
                            }}
                          />
                          <button className="save" type="button" onClick={() => handleInlineSave(student)}>✔</button>
                          <button className="cancel" type="button" onClick={cancelEditing}>✖</button>
                        </>
                      ) : (
                        <span
                          className="val"
                          onClick={() => startEditing(key, 'name_en', student.name_en || student.name || '')}
                          title="Click to edit name"
                        >
                          <div className="name-en">{student.name_en || student.name || '—'}</div>
                          {student.name_ar && <div className="name-ar">{student.name_ar}</div>}
                          {isDup && <div className="dup-tag">{t.duplicateTag}</div>}
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Age */}
                  <td>
                    <div className={`inline ${isFieldEditing('age') ? 'editing' : ''}`}>
                      {isFieldEditing('age') ? (
                        <>
                          <input
                            autoFocus
                            value={editing?.value || ''}
                            onChange={(e) => setEditing((prev) => prev ? { ...prev, value: e.target.value } : null)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleInlineSave(student);
                              if (e.key === 'Escape') cancelEditing();
                            }}
                          />
                          <button className="save" type="button" onClick={() => handleInlineSave(student)}>✔</button>
                          <button className="cancel" type="button" onClick={cancelEditing}>✖</button>
                        </>
                      ) : (
                        <span
                          className="val"
                          onClick={() => startEditing(key, 'age', student.age || '')}
                          title="Click to edit age"
                        >
                          {student.age || '—'}
                        </span>
                      )}
                    </div>
                  </td>

                  {/* National ID / Iqama */}
                  <td>
                    <div className={`inline ${isFieldEditing('iqama') ? 'editing' : ''}`}>
                      {isFieldEditing('iqama') ? (
                        <>
                          <input
                            autoFocus
                            value={editing?.value || ''}
                            onChange={(e) => setEditing((prev) => prev ? { ...prev, value: e.target.value } : null)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleInlineSave(student);
                              if (e.key === 'Escape') cancelEditing();
                            }}
                          />
                          <button className="save" type="button" onClick={() => handleInlineSave(student)}>✔</button>
                          <button className="cancel" type="button" onClick={cancelEditing}>✖</button>
                        </>
                      ) : (
                        <span
                          className="val"
                          onClick={() => startEditing(key, 'iqama', student.iqama || '')}
                          title="Click to edit ID"
                        >
                          {student.iqama || '—'}
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Phone */}
                  <td>
                    <div className={`inline ${isFieldEditing('phone') ? 'editing' : ''}`}>
                      {isFieldEditing('phone') ? (
                        <>
                          <input
                            autoFocus
                            value={editing?.value || ''}
                            onChange={(e) => setEditing((prev) => prev ? { ...prev, value: e.target.value } : null)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleInlineSave(student);
                              if (e.key === 'Escape') cancelEditing();
                            }}
                          />
                          <button className="save" type="button" onClick={() => handleInlineSave(student)}>✔</button>
                          <button className="cancel" type="button" onClick={cancelEditing}>✖</button>
                        </>
                      ) : (
                        <span
                          className="val"
                          onClick={() => startEditing(key, 'phone', student.phone || '')}
                          title="Click to edit phone"
                        >
                          {student.phone || '—'}
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Previous Course */}
                  <td>{student.status === 'new' ? '—' : student.previousCourse || '—'}</td>

                  {/* Current Course */}
                  <td className="col-course">{student.course || '—'}</td>

                  {/* Period */}
                  <td className="col-period period-ltr">{student.period || '—'}</td>

                  {/* Trainer */}
                  <td className="col-trainer">{student.trainer || '—'}</td>

                  {/* Room */}
                  <td className="col-room">{student.room || '—'}</td>

                  {/* Target Course */}
                  <td title={targetText}>{targetText}</td>

                  {/* Total Levels */}
                  <td id={`tl-${domRowId}`}>{displayTotal}</td>

                  {/* Used Levels */}
                  <td id={`ul-${domRowId}`}>
                    {displayUsed}
                    {isSubEnded(displayTotal, displayUsed) && (
                      <div style={{ marginTop: '6px' }}>
                        <span className="end-sub-alert">{t.subEndedAlert}</span>
                      </div>
                    )}
                  </td>

                  {/* Remaining Levels */}
                  <td id={`rl-${domRowId}`}>{displayRem}</td>

                  {/* Course Fee */}
                  <td id={`fee-${domRowId}`}>{Number(student.CourseFee || 0)}</td>

                  {/* Paid Amount */}
                  <td id={`paid-${domRowId}`}>{Number(student.PaidAmount || 0)}</td>

                  {/* Remaining Amount */}
                  <td id={`rem-${domRowId}`}>{renderRemainingAmount(student.RemainingAmount || 0)}</td>

                  {/* Payment Type */}
                  <td id={`method-${domRowId}`}>{student.PaymentType || '—'}</td>

                  {/* Grade */}
                  <td>{student.grade === 0 || student.grade ? student.grade : '—'}</td>

                  {/* Status */}
                  <td>{renderStatus(student.status)}</td>

                  {/* Date */}
                  <td>{student.date || '—'}</td>

                  {/* Actions (mini-pay, mini-lv) */}
                  <td className="mini-actions">
                    <button
                      className="mini mini-pay"
                      type="button"
                      onClick={() => onOpenFees(student)}
                    >
                      <i className="fa-solid fa-credit-card"></i>
                      <span>{t.btnPayments}</span>
                    </button>
                    <button
                      className="mini mini-lv"
                      type="button"
                      onClick={() => onOpenLevels(student)}
                    >
                      <i className="fa-solid fa-layer-group"></i>
                      <span>{t.btnLevels}</span>
                    </button>
                  </td>

                  {/* Result (migrated/deleted badge + undo) */}
                  <td id={`res-${domRowId}`}>
                    {isDone && undoItem ? (
                      <>
                        <span className={undoItem.type === 'migrate' ? 'badge-move' : 'badge-del'}>
                          {undoItem.type === 'migrate' ? t.migratedBadge : t.deletedBadge}
                        </span>{' '}
                        <span className="undo" onClick={() => onUndo(key)}>
                          {t.undoBtn}
                        </span>
                      </>
                    ) : (
                      '—'
                    )}
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};

export type Language = 'en' | 'ar';

export type StudentSource = 'FakeRegistrations' | 'FakePromotions';

export interface LevelInfo {
  total: number;
  used: number;
  remaining: number;
}

export interface StudentRecord {
  src: StudentSource;
  id: string;
  raw: Record<string, any>;
  name_en: string;
  name: string;
  name_ar: string;
  age: string;
  iqama: string;
  phone: string;
  course: string;
  previousCourse: string;
  period: string;
  room: string;
  trainer: string;
  totalLevels: number | string;
  usedLevels: number | string;
  remainingLevels: number | string;
  _lastLevels: LevelInfo | null;
  CourseFee: number;
  PaidAmount: number;
  RemainingAmount: number;
  PaymentType: string;
  grade: number | string;
  status: 'new' | 'pass' | 'fail';
  date: string;
}

export interface CourseRecord {
  id: string;
  TrainingCourse?: string;
  Period?: string;
  period?: string;
  Trainer?: string;
  Room?: string;
  room?: string;
  Branch?: string;
  Section?: string | string[];
  CourseType?: string;
  status?: string;
  CourseFee?: number | string;
  [key: string]: any;
}

export interface UndoRecord {
  type: 'migrate' | 'delete';
  src: StudentSource;
  id: string;
  raw: Record<string, any>;
  studentId?: string;
}

export interface FilterState {
  status: string;
  name: string;
  age: string;
  iqama: string;
  phone: string;
  course: string;
  period: string;
  room: string;
  date: string;
}
